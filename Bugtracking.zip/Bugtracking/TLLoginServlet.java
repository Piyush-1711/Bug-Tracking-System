import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class TLLoginServlet extends HttpServlet {
  protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    String username = request.getParameter("username");
    String password = request.getParameter("password");

    if ("TL".equals(username) && "TL123".equals(password)) {
      // Redirect to TL Home page
      response.sendRedirect("tl_home.html");
    } else {
      // Invalid credentials: Show error message
      PrintWriter out = response.getWriter();
      response.setContentType("text/html");
      out.println("<html><body style='text-align:center; font-family:sans-serif; background-color:#fce4e4;'>");
      out.println("<h2 style='color:red;'>Invalid Credentials</h2>");
      out.println("<p><a href='tl_login.html'>Go Back</a></p>");
      out.println("</body></html>");
    }
  }
}
