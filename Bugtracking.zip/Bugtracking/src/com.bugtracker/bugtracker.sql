CREATE DATABASE bugtracker;
USE bugtracker;

CREATE TABLE tasks (
  id INT PRIMARY KEY AUTO_INCREMENT,
  title VARCHAR(100),
  description TEXT
);
