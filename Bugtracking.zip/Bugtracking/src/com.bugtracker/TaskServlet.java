package com.bugtracker;

import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;
import javax.servlet.*;
import javax.servlet.http.*;

public class TaskServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        ArrayList<Task> tasks = new ArrayList<>();
        try (Connection con = DBConnection.getConnection()) {
            PreparedStatement ps = con.prepareStatement("SELECT * FROM tasks");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                tasks.add(new Task(rs.getString("title"), rs.getString("description")));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        request.setAttribute("taskList", tasks);
        RequestDispatcher rd = request.getRequestDispatcher("assigned-tasks.jsp");
        rd.forward(request, response);
    }
}
