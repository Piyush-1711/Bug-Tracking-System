CREATE DATABASE bug_tracking;

USE bug_tracking;

CREATE TABLE developers (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100),
  email VARCHAR(100),
  password VARCHAR(100),
  domain VARCHAR(100),
  phone VARCHAR(20),
  location VARCHAR(100)
);
