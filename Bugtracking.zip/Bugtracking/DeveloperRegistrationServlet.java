import java.io.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.sql.*;

@WebServlet("/DeveloperRegistrationServlet")
public class DeveloperRegistrationServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {

        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        String domain = request.getParameter("domain");
        String phone = request.getParameter("phone");
        String location = request.getParameter("location");

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/bug_tracking", "root", "your_password");

            String query = "INSERT INTO developers(name, email, password, domain, phone, location) VALUES (?, ?, ?, ?, ?, ?)";
            PreparedStatement pst = conn.prepareStatement(query);

            pst.setString(1, name);
            pst.setString(2, email);
            pst.setString(3, password);
            pst.setString(4, domain);
            pst.setString(5, phone);
            pst.setString(6, location);

            int i = pst.executeUpdate();
            PrintWriter out = response.getWriter();
            if (i > 0) {
                out.println("<h2>Developer Registered Successfully!</h2>");
            } else {
                out.println("<h2>Error! Please try again.</h2>");
            }

            pst.close();
            conn.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
